/*
 * Browser-safe Supabase connection settings.
 * The publishable key is intentionally public. Never place a secret key,
 * service_role key, database password, or connection string in this file.
 */
window.FCMG_ONLINE_CONFIG = Object.freeze({
  supabaseUrl: "https://qkcuhludisairpgzhryl.supabase.co",
  supabasePublishableKey: "sb_publishable_V3J-pEP-TxR4Bqq8bToJeQ_EeEcwncn"
});
