# Version

- Product: Four Color Map Game
- Version: 5.0.0-online-rc1
- Base game: v4.9 Modes & Collection
- Release type: online multiplayer release candidate
- Supabase JS: 2.112.4 (CDN pin)
- Transport: Postgres Changes Realtime + 2.5 second polling fallback
- Database migration: `supabase/001_online_rooms.sql`
