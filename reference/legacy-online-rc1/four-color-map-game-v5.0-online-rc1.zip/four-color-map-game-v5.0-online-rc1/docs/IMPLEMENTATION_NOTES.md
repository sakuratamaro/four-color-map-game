# Online RC1 Implementation Notes

## 状態同期単位

ゲームエンジンの`game`オブジェクト全体をJSONBへ変換して同期します。`Set`と特殊数値は次のwire形式へ変換します。

- `Set` → `{ "$set": [...] }`
- `Infinity` → `{ "$number": "Infinity" }`
- `-Infinity` → `{ "$number": "-Infinity" }`
- `NaN` → `{ "$number": "NaN" }`

これにより、v4.9の幾何状態を大規模に分解せずオンライン化しています。

## 更新競合

各ルームは`version bigint`を持ちます。クライアントは最後に読んだversionを`p_expected_version`として送信し、DB側が一致しない更新を`version_conflict`で拒否します。

DB側は保存済み状態の`active`とRPC呼出ユーザーの席を比較し、現在手番でないプレイヤーの更新を`not_your_turn`で拒否します。

## Realtimeとポーリング

即時更新は`postgres_changes`を使用します。WebSocket切断、タブ復帰、Realtime購読失敗に備え、2.5秒ごとにもルーム行を再取得します。

## ローカルプロフィールとの境界

クイズ、ガチャ、カード所持、コイン、外観は従来どおり各ブラウザの`localStorage`へ保存します。オンラインルームへは対戦開始時の表示名・モード・持込設定だけをコピーします。

熟考モードでカードが正常発動した回数をゲーム状態の`consumedBySkill`へ記録し、各端末が自席分だけをローカル在庫へ一度だけ反映します。二重反映防止台帳は`fourColorMapGame.online.ledger.v1`です。

## セキュリティ境界

第三者のルーム行アクセスと直接書込みはRLS・権限・RPCで制限します。ただしRC1は参加者間の完全な秘密分離を行っていません。サーバー権威型へ進める場合は、公開状態、A秘密状態、B秘密状態、検証済みアクション履歴を分離する設計へ変更します。
